KEYHUB SETUP — exact order

1. Install Node.js and Firebase CLI on a PC.
2. Create a Firebase project at Firebase Console.
3. Enable Authentication > Sign-in method > Email/Password.
4. Create a Firestore database.
5. Add a Web App in Firebase Project Settings.
6. Copy its firebaseConfig into app.js where PA... values are shown.
7. Create an account from the website.
8. Open Firebase Authentication > Users and copy that account's UID.
9. Put that UID into functions/index.js:
   const ADMIN_UID="YOUR_UID";
10. Open a terminal in this project folder.
11. Run:
   firebase login
   firebase use YOUR_PROJECT_ID
   firebase deploy --only firestore:rules,functions,hosting

12. Open the Hosting URL.

DEFAULT ROLE:
- The first/admin UID is admin.
- Other registered users become reseller accounts in this starter.
- Admin can create tokens for reseller UIDs.
- Resellers need their assigned active token to generate keys.

PLANS:
Create plans manually in Firestore collection "plans" with fields:
name: Starter
price: 29
keys: 10
days: 30

Suggested:
Starter ₹29 / 10 keys / 30 days
Basic ₹99 / 50 keys / 30 days
Pro ₹199 / 120 keys / 60 days
Premium ₹499 / 350 keys / 90 days
Unlimited ₹999 / 1000 keys / 365 days

APP DOWNLOADS:
Admin adds an app with a download URL. Only upload/distribute APKs you are authorized to distribute.

IMPORTANT SECURITY:
The key/token operations are server-side Cloud Functions. Do not move token validation or key generation into only client-side JavaScript.
