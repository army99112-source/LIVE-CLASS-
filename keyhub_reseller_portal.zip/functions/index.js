const {onCall,HttpsError} = require("firebase-functions/v2/https");
const {setGlobalOptions} = require("firebase-functions/v2");
const admin=require("firebase-admin");
const crypto=require("crypto");
admin.initializeApp();
setGlobalOptions({region:"asia-south1",maxInstances:10});
const db=admin.firestore();

/*
 IMPORTANT:
 1) Register your own account.
 2) Copy your Firebase Auth UID.
 3) Put that UID into ADMIN_UID below.
 4) Deploy functions again.
*/
const ADMIN_UID="PASTE_YOUR_ADMIN_UID_HERE";

function requireAuth(req){
  if(!req.auth) throw new HttpsError("unauthenticated","Login required.");
}
async function isAdmin(uid){
  return uid===ADMIN_UID;
}
async function profile(uid){
  const s=await db.doc(`users/${uid}`).get();
  return s.exists?s.data():null;
}
function tokenString(prefix="RSL"){
  return prefix+"-"+crypto.randomBytes(10).toString("hex").toUpperCase();
}

exports.createProfile=onCall(async req=>{
  requireAuth(req);
  const uid=req.auth.uid, existing=await profile(uid);
  if(existing) return {ok:true};
  const user=await admin.auth().getUser(uid);
  await db.doc(`users/${uid}`).set({
    name:String(req.data?.name||"User"),
    email:user.email||"",
    role:uid===ADMIN_UID?"admin":"reseller",
    createdAt:admin.firestore.FieldValue.serverTimestamp()
  });
  return {ok:true};
});

exports.createResellerToken=onCall(async req=>{
  requireAuth(req);
  if(!(await isAdmin(req.auth.uid))) throw new HttpsError("permission-denied","Admin only.");
  const ownerId=String(req.data?.ownerId||"");
  const days=Math.max(1,Math.min(3650,Number(req.data?.days||30)));
  const owner=await profile(ownerId);
  if(!owner) throw new HttpsError("not-found","Reseller UID not found.");
  const token=tokenString();
  const expires=new Date(Date.now()+days*86400000).toISOString();
  await db.collection("tokens").add({
    token,ownerId,status:"active",expiresAt:expires,
    createdAt:admin.firestore.FieldValue.serverTimestamp()
  });
  return {token,expiresAt:expires};
});

exports.generateKey=onCall(async req=>{
  requireAuth(req);
  const p=await profile(req.auth.uid);
  if(!p || !["admin","reseller"].includes(p.role))
    throw new HttpsError("permission-denied","Reseller account required.");

  const token=String(req.data?.token||"").trim();
  const days=Math.max(1,Math.min(3650,Number(req.data?.days||30)));
  if(!token) throw new HttpsError("invalid-argument","Token required.");

  const snap=await db.collection("tokens").where("token","==",token).limit(1).get();
  if(snap.empty) throw new HttpsError("permission-denied","Invalid token.");
  const td=snap.docs[0].data();
  if(td.ownerId!==req.auth.uid && !await isAdmin(req.auth.uid))
    throw new HttpsError("permission-denied","This token is not assigned to you.");
  if(td.status!=="active" || new Date(td.expiresAt)<new Date())
    throw new HttpsError("permission-denied","Token expired or inactive.");

  const key="KH-"+crypto.randomBytes(12).toString("hex").toUpperCase();
  const expires=new Date(Date.now()+days*86400000).toISOString();
  await db.collection("keys").add({
    key,ownerId:req.auth.uid,tokenId:snap.docs[0].id,
    status:"active",expiresAt:expires,
    createdAt:admin.firestore.FieldValue.serverTimestamp()
  });
  return {key,expiresAt:expires};
});

exports.addApp=onCall(async req=>{
  requireAuth(req);
  if(!(await isAdmin(req.auth.uid))) throw new HttpsError("permission-denied","Admin only.");
  const name=String(req.data?.name||"").trim();
  const version=String(req.data?.version||"").trim();
  const url=String(req.data?.url||"").trim();
  if(!name||!version||!url) throw new HttpsError("invalid-argument","Name, version and URL required.");
  await db.collection("apps").add({
    name,version,url,
    icon:String(req.data?.icon||""),
    description:String(req.data?.description||""),
    createdAt:admin.firestore.FieldValue.serverTimestamp()
  });
  return {ok:true};
});
